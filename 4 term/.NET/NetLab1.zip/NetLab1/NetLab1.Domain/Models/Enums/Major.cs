﻿namespace NetLab1.Domain.Models.Enums;

public enum Major
{
    ComputerScience,
    Physics,
    Math
}