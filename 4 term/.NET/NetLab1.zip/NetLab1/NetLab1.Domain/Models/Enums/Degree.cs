﻿namespace NetLab1.Domain.Models.Enums;

public enum Degree
{
    Bachelor,
    Master,
    PhD
}