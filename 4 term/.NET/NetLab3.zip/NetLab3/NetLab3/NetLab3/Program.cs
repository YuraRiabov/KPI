﻿using NetLab3;

new IOManager().Process();