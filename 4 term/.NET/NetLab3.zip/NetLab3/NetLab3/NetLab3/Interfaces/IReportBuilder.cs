﻿namespace NetLab3.Interfaces;

public interface IReportBuilder
{
    
}