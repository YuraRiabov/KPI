﻿using NetLab5;

new IOManager(Console.ReadLine, Console.WriteLine).Process();