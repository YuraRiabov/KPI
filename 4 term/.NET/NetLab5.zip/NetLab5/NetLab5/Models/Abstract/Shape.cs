﻿namespace NetLab5.Models.Abstract;

public abstract class Shape
{
    public abstract void Draw();
}