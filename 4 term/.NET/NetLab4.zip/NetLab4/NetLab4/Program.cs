﻿using NetLab4;

new IOManager(Console.WriteLine, Console.ReadLine).Process();