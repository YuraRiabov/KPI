﻿namespace NetLab4.Models.Enums;

public enum ListingType
{
    Numbered,
    Lettered,
    Dashed,
    Tabbed
}