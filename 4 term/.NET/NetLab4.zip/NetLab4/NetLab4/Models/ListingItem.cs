﻿namespace NetLab4.Models;

public record ListingItem : TopLevelTextItem;