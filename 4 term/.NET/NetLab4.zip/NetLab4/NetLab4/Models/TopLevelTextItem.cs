﻿namespace NetLab4.Models;

public record TopLevelTextItem;