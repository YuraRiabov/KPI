﻿namespace NetLab4.Models;

public record Token(string Value);